package signin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class signin {
	
		public void register(WebDriver dr)
		{
			dr.findElement(By.xpath("//*[@id=\"Catalog\"]/a")).click();
		}
		
		
		public void signIn(WebDriver dr)
		{
			dr.findElement(By.name("username")).click();
			dr.findElement(By.name("username")).clear();
			dr.findElement(By.name("username")).sendKeys("Ayush");
			dr.findElement(By.name("password")).click();
			dr.findElement(By.name("password")).clear();
			dr.findElement(By.name("password")).sendKeys("Ayush1");
			dr.findElement(By.name("signon")).click();

			
			

		}
		
		
	
	
}

 
