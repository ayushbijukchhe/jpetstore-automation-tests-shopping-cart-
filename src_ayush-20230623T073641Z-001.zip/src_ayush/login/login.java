package login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class login {
	
	public void login(WebDriver dr){
		dr.findElement(By.linkText("Sign In")).click();
			
		dr.findElement(By.name("username")).click();
		dr.findElement(By.name("username")).clear();
		dr.findElement(By.name("username")).sendKeys("001");
		dr.findElement(By.name("password")).click();
		dr.findElement(By.name("password")).clear();
		dr.findElement(By.name("password")).sendKeys("12345");
		dr.findElement(By.name("signon")).click();

	
	}
	
	
	public void clickRegisterNow(WebDriver dr) {
		
		dr.findElement(By.linkText("Register Now!")).click();
	}

}
