package selenium;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import homepage.homepage;
import login.login;
import order.order;

public class TC008 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriver driver = new ChromeDriver();
		
		String extentReportFile = System.getProperty("user.dir")+ "\\TC008.html";
		//String extentReportImage = System.getProperty("user.dir")	+ "\\extentReportImage.png";

		// Create object of extent report and specify the report file path.
		ExtentReports extent = new ExtentReports(extentReportFile, false);

		// Start the test using the ExtentTest class object.
		ExtentTest extentTest = extent.startTest("TC008", "Verify the items stays in the cart even after logging out of the system");

		
		System.setProperty("webdriver.driver.chrome", "C:\\Users\\ayush\\eclipse-workspace\\testcases\\extention\\chromedriver.exe");
		
		driver.get("https://petstore.octoperf.com");
		
		System.out.println("1. Open chrome and enter the URL");
		extentTest.log(LogStatus.INFO, "1. Open chrome and enter the URL");
		
		driver.findElement(By.linkText("Enter the Store")).click();
		System.out.println("2. Click on link text.");
		extentTest.log(LogStatus.INFO, "2. Click on link text.");


		
		login log = new login();
		
		log.login(driver);
		System.out.println("3. Login with correct credentials.");
		extentTest.log(LogStatus.INFO, "3. Login with correct credentials.");


		
		order or = new order();
		
		or.orderItem(driver);
		System.out.println("4. Add Multiple items into the cart");
		extentTest.log(LogStatus.INFO, "4. Add Multiple items into the cart");


						
		driver.findElement(By.linkText("Sign Out")).click();
		System.out.println("5. Sign out from the site");
		extentTest.log(LogStatus.INFO, "5. Sign out from the site");

		
		log.login(driver);
		System.out.println("6. Login Again");
		extentTest.log(LogStatus.INFO, "6. Login Again");

		
		homepage home = new homepage();
		
		home.clickCart(driver);
		System.out.println("7. Click on cart icon");
		extentTest.log(LogStatus.INFO, "7. Click on cart icon");

		
		String message = driver.findElement(By.xpath("//*[@id=\"Cart\"]/form/table/tbody/tr[2]/td/b")).getText();
		
		String actualResult = "Your cart is empty.";
				
				if (message.equals(actualResult)) {
					
					System.out.println("Test Fail");
					extentTest.log(LogStatus.FAIL, "TEST FAIL");
				}
		
				else {
					System.out.println("Fail");
					extentTest.log(LogStatus.PASS, "TEST PASS");
				}
				
				extent.endTest(extentTest);
				extent.flush();
		
		
		
		
		

	}

}
