package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import order.order;
import shoppingcart.shoppingcart;

public class TC006 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver = new ChromeDriver();
		
		String extentReportFile = System.getProperty("user.dir")+ "\\TC006.html";
		//String extentReportImage = System.getProperty("user.dir")	+ "\\extentReportImage.png";

		// Create object of extent report and specify the report file path.
		ExtentReports extent = new ExtentReports(extentReportFile, false);

		// Start the test using the ExtentTest class object.
		ExtentTest extentTest = extent.startTest("TC006", "Verify that the quantity input field does not accept 0 values");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\ayush\\eclipse-workspace\\testcases\\extention\\chromedriver.exe");
		
		driver.get("https://petstore.octoperf.com");
		
		System.out.println("1. Open chorme and enter the URL");
		
		extentTest.log(LogStatus.INFO, "");
		
		driver.findElement(By.linkText("Enter the Store")).click();
		
		order orderobj = new order();
		
		orderobj.orderItem(driver);
		
		System.out.println("2.Add multiple items in the cart.");
		
		extentTest.log(LogStatus.INFO, "2.Add multiple items in the cart.");


		
		shoppingcart zero = new shoppingcart();
		
		zero.changeValueToZero(driver);
		
		System.out.println("3. Change quantity value to zero");
		
		extentTest.log(LogStatus.INFO, "3. Change quantity value to zero");


		
		String expectedResult = "Invalid Data";
		
		
		String actualResult = driver.findElement(By.xpath("//*[@id=\"Cart\"]/h2")).getText();
				
		if (expectedResult.equals(actualResult)) {
			System.out.println("Test Pass");
			
			extentTest.log(LogStatus.PASS, "TEST PASS");

		}
		
		else {
			System.out.println("Test Fail");
			extentTest.log(LogStatus.FAIL, "TEST FAIL");

		}
		
	extent.endTest(extentTest);
	extent.flush();
		
		
		

	}

}
