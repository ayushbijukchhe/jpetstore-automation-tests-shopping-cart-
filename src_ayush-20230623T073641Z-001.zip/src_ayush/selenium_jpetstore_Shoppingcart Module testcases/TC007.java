package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import order.order;
import shoppingcart.shoppingcart;

public class TC007 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriver driver = new ChromeDriver();
		
		String extentReportFile = System.getProperty("user.dir")+ "\\TC007.html";
		//String extentReportImage = System.getProperty("user.dir")	+ "\\extentReportImage.png";

		// Create object of extent report and specify the report file path.
		ExtentReports extent = new ExtentReports(extentReportFile, false);

		// Start the test using the ExtentTest class object.
		ExtentTest extentTest = extent.startTest("TC007", "Verify that the quantity input field does not accept negative values");

		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\ayush\\eclipse-workspace\\selenium\\extention\\chromedriver.exe");

		driver.get("https://petstore.octoperf.com");
		
		System.out.println("1.open browser and enter URL");
		
		extentTest.log(LogStatus.INFO, "1.open browser and enter URL");
		
		driver.findElement(By.linkText("Enter the Store")).click();
		
		System.out.println("2. Click on the enter the store link");
		
		extentTest.log(LogStatus.INFO, "2. Click on the enter the store link");
		
		order orderobj = new order();
		
		orderobj.orderItem(driver);
		
		System.out.println("3. Add Multiple items in cart");
		extentTest.log(LogStatus.INFO, "3. Add Multiple items in cart");

		
		shoppingcart negative = new shoppingcart();
		
		negative.changeValueToNegative(driver);
		
		System.out.println("4. Change value in Quantity field to negative");
		extentTest.log(LogStatus.INFO, "4. Change value in Quantity field to negative");

		String expectedResult = driver.findElement(By.xpath("//*[@id=\"Cart\"]/form/table/tbody/tr[2]/td[1]/a")).getText();
		
		String actualResult = "EST-1";
		
		if (expectedResult.equals(actualResult)) {
			System.out.println("PASS");
			extentTest.log(LogStatus.PASS, "PASS");
		}
		else {
			System.out.println("FAIL");
			extentTest.log(LogStatus.FAIL, "FAIL");
		}
	}

}
