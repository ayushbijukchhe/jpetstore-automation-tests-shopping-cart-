package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import angelfish.angelfish;
import fish.fish;
import homepage.homepage;
import shoppingcart.shoppingcart;

public class TC003 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriver driver = new ChromeDriver();
		
		String extentReportFile = System.getProperty("user.dir")+ "\\TC003.html";
		//String extentReportImage = System.getProperty("user.dir")	+ "\\extentReportImage.png";

		// Create object of extent report and specify the report file path.
		ExtentReports extent = new ExtentReports(extentReportFile, false);

		// Start the test using the ExtentTest class object.
		ExtentTest extentTest = extent.startTest("TC003", "Verify that prices are changed from cart");
		
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\ayush\\eclipse-workspace\\testcases\\extention\\chromedriver.exe");
		
		driver.get("https://petstore.octoperf.com");
		
		System.out.println("1. Open Chrome and enter the URL");
		
		extentTest.log(LogStatus.INFO, "1. Open chrome and enter the URL");
		
		driver.findElement(By.linkText("Enter the Store")).click();
		
		homepage home = new homepage();
		
		home.clickFish(driver);
		
		System.out.println("2. Click Fish");
		
		extentTest.log(LogStatus.INFO, "2. Click fish");

		
		fish clickdes = new fish();
		
		clickdes.clickFish(driver);
		
		System.out.println("3. Click description of fish");
		
		extentTest.log(LogStatus.INFO, "3.Click description of angelfish");
		
		angelfish cart = new angelfish();
		
		cart.clickAddTocart(driver);
		
		System.out.println("4. Click add to cart Button");
		
		extentTest.log(LogStatus.INFO, "3.Click description of angelfish");

		
		shoppingcart update = new shoppingcart();
		 update.changeValue(driver);
		 
		 System.out.println("5. Change the value of quantity and update the prices.");
		
			extentTest.log(LogStatus.INFO, "5. Change the value of quantity and update the prices. ");

		 
		String expectedPrice = "$1,650.00";
		
		String actualPrice = driver.findElement(By.xpath("//*[@id=\"Cart\"]/form/table/tbody/tr[2]/td[7]")).getText();
		
		if (expectedPrice.equals(actualPrice)) {
			System.out.println("Test Pass");
			
			extentTest.log(LogStatus.PASS, "TEST PASS");
		}
		
		else {
			System.out.println("Test Fail!");
			
			extentTest.log(LogStatus.FAIL, "FAIL");
		}
		
		extent.endTest(extentTest);
		extent.flush();
		
		
		
		
	}

}
