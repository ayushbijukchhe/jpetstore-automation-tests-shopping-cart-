package selenium;

import java.sql.Driver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import homepage.homepage;
import signin.signin;

public class tosignin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriver driver = new ChromeDriver();
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\ayush\\eclipse-workspace\\testcases\\extention\\chromedriver.exe");

		driver.get("https://petstore.octoperf.com");
		
		driver.findElement(By.linkText("Enter the Store")).click();
		
		homepage home = new homepage();
		
		home.clickSignIn(driver);
		
		signin si = new signin();
		
		si.signIn(driver);
		
		String expectedResult = "Welcome Ayush!";
		
		String actualResult = driver.findElement(By.xpath("//*[@id=\"WelcomeContent\"]")).getText();
		
		if (expectedResult.equals(actualResult)) {
			System.out.println("test pass");
			
		}
		
		else {
			System.out.println("fail");
		}
		
		
	}

}
