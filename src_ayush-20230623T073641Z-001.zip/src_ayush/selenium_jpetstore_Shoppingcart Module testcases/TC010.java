package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import login.login;
import order.order;
import shoppingcart.shoppingcart;

public class TC010 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriver driver = new ChromeDriver();
		
		String extentReportFile = System.getProperty("user.dir")+ "\\TC010.html";
		//String extentReportImage = System.getProperty("user.dir")	+ "\\extentReportImage.png";

		// Create object of extent report and specify the report file path.
		ExtentReports extent = new ExtentReports(extentReportFile, false);

		// Start the test using the ExtentTest class object.
		ExtentTest extentTest = extent.startTest("TC010", "Verify that the user is prompted to log in or create an account before checking out.");

		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\ayush\\eclipse-workspace\\testcases\\extention\\chromedriver.exe");
		
		driver.get("https://petstore.octoperf.com/");
		
		extentTest.log(LogStatus.INFO, "1.Open chrome and enter the URL");

		
		driver.findElement(By.linkText("Enter the Store")).click();
		
		extentTest.log(LogStatus.INFO, "2.Click on the link text");

		
		order addItems = new order();
		
		
		addItems.orderItem(driver);
		
		extentTest.log(LogStatus.INFO, "3.Put items in Shopping Cart (angelfish and bulldog)");

		
		shoppingcart proceed = new shoppingcart();
		
		proceed.proceedToCheckout(driver);
		
		extentTest.log(LogStatus.INFO, "4. Click on Proceed to checkout button");
		
		login register = new login();
		
		register.clickRegisterNow(driver);
		
		extentTest.log(LogStatus.INFO, "5. Click on register now button");


		
		String expectedMessage = "User Information";
		
		String actualMessage = driver.findElement(By.xpath("//*[@id=\"Catalog\"]/form/h3[1]")).getText();
		
		if (expectedMessage.equals(actualMessage)) {
			System.out.println("TEST PASS");
			
			extentTest.log(LogStatus.PASS, "TEST PASS");

		}
		
		else {
			System.out.println("TEST FAIL");
			extentTest.log(LogStatus.FAIL, "TEST FAIL");

		}
		
		extent.endTest(extentTest);
		extent.flush();
		
		
	}

}
