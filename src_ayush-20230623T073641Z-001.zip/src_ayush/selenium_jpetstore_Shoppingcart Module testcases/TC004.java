package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import angelfish.angelfish;
import fish.fish;
import homepage.homepage;
import shoppingcart.shoppingcart;

public class TC004 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriver driver = new ChromeDriver();
		
		String extentReportFile = System.getProperty("user.dir")+ "\\TC004.html";
		//String extentReportImage = System.getProperty("user.dir")	+ "\\extentReportImage.png";

		// Create object of extent report and specify the report file path.
		ExtentReports extent = new ExtentReports(extentReportFile, false);

		// Start the test using the ExtentTest class object.
		ExtentTest extentTest = extent.startTest("TC004", "Verify that prices are changed if quantity are changed to symbol from cart");

		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\ayush\\eclipse-workspace\\testcases\\extention\\chromedriver.exe");
		
		driver.get("https://petstore.octoperf.com/");
		
		System.out.println("1. Open Chrome and enter the URL");

		extentTest.log(LogStatus.INFO, "1. Open Chrome and enter the URL");
		
		driver.findElement(By.linkText("Enter the Store")).click();
		
		System.out.println("2. Click on Link Text");
		
		extentTest.log(LogStatus.INFO, "2. Click on Link Text");
		
		homepage home = new homepage();
		
		home.clickFish(driver);
		
		System.out.println("3. Click on FIsh");
		
		extentTest.log(LogStatus.INFO, "3. Click on FIsh");
		
		fish clickdes = new fish();
		
		clickdes.clickFish(driver);
			
		System.out.println("4. Click angelfish description.");
		
		extentTest.log(LogStatus.INFO, "4. Click angelfish description.");

		angelfish cart = new angelfish();
		
		cart.clickAddTocart(driver);
		
		System.out.println("5. Click add to cart button.");
		extentTest.log(LogStatus.INFO, "5. Click add to cart button.");
		
		shoppingcart update = new shoppingcart();
		 update.changeValueToSymbol(driver);
		 
			System.out.println("6. Change value to symbol.");
			extentTest.log(LogStatus.INFO, "6. Change value to symbol.\"");


		
		//verification needed
		
		

	}

}
