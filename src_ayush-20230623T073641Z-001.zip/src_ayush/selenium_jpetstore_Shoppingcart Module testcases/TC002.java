package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import angelfish.angelfish;
import fish.fish;
import homepage.homepage;
import shoppingcart.shoppingcart;


public class TC002 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
				
		WebDriver driver = new ChromeDriver();
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\ayush\\eclipse-workspace\\selenium\\extention\\chromedriver.exe");

		String extentReportFile = System.getProperty("user.dir")+ "\\TC002.html";
		//String extentReportImage = System.getProperty("user.dir")	+ "\\extentReportImage.png";

		// Create object of extent report and specify the report file path.
		ExtentReports extent = new ExtentReports(extentReportFile, false);

		// Start the test using the ExtentTest class object.
		ExtentTest extentTest = extent.startTest("TC002", "Verify ability to remove item from cart");
		
		System.out.println("1.Open browser and enter the URL");
		
		extentTest.log(LogStatus.INFO, "1.Open browser and enter the URL");


		driver.get("https://petstore.octoperf.com");
		
		System.out.println("2. Click on the enter the store link");
		extentTest.log(LogStatus.INFO, "2. Click on the enter the store link");

		
		driver.findElement(By.linkText("Enter the Store")).click();
		
		homepage home = new homepage();
		
		home.clickFish(driver);
		
		System.out.println("2. Click on fish");
		extentTest.log(LogStatus.INFO, "2. Click on the enter the store link");

		
		fish clickfish = new fish();
		
		System.out.println("3. Click on angelfish description");
		extentTest.log(LogStatus.INFO, "3. Click on angelfish description");

		clickfish.clickFish(driver);
		
		angelfish clickangelfish = new angelfish();
		
		System.out.println("4. Click on add to cart");
		extentTest.log(LogStatus.INFO, "4. Click on add to cart");

		clickangelfish.clickAddTocart(driver);
		
		shoppingcart cart = new shoppingcart();
		
		System.out.println("5. Remove items from the cart");
		extentTest.log(LogStatus.INFO, "5. Remove items from the cart");

		cart.removeItems(driver);
		
		String expectedResult = "Your cart is empty.";
		
		String actualResult = driver.findElement(By.xpath("//*[@id=\"Cart\"]/form/table/tbody/tr[2]/td/b")).getText();
		
		if (expectedResult.equals(actualResult)) {
			
			System.out.println("Test Pass");
			extentTest.log(LogStatus.PASS, "TEST PASS");
			
		}
		
		else {
			System.out.println("Test Fail");
			
			extentTest.log(LogStatus.FAIL, "TEST FAIL");

		}
		
		extent.endTest(extentTest);
		extent.flush();
	
		
			
	}

}
