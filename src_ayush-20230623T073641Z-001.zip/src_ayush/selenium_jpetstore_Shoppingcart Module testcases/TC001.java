package selenium;
import org.openqa.selenium.By;
import com.relevantcodes.extentreports.ExtentReports;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import angelfish.angelfish;
import fish.fish;
import homepage.homepage;
import shoppingcart.shoppingcart;


public class TC001 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver = new ChromeDriver();
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\ayush\\eclipse-workspace\\selenium\\extention\\chromedriver.exe");
		
		String extentReportFile = System.getProperty("user.dir")+ "\\TC001.html";
		//String extentReportImage = System.getProperty("user.dir")	+ "\\extentReportImage.png";

		// Create object of extent report and specify the report file path.
		ExtentReports extent = new ExtentReports(extentReportFile, false);

		// Start the test using the ExtentTest class object.
		ExtentTest extentTest = extent.startTest("TC001", "Verify ability to view cart");

		System.out.println("1.open chrome");
		
		extentTest.log(LogStatus.INFO, "1.open chrome");
	
		
		driver.get("https://petstore.octoperf.com");
		
		System.out.println("2. Enter the URL");
		
		extentTest.log(LogStatus.INFO, "2. Enter the URL");
		
		
		homepage home = new homepage();
		fish fishob = new fish();
		
		System.out.println("3. Click on the enter the store link");
		
		extentTest.log(LogStatus.INFO, "3. Click on the enter the store link");

		
		driver.findElement(By.linkText("Enter the Store")).click();
		
		
		home.clickFish(driver);	
		
		System.out.println("4. Click on Fish");
		
		extentTest.log(LogStatus.INFO, "4. Click on Fish");
		
		fishob.clickFish(driver);
		
		System.out.println("5.Click on AngelFish");
		
		extentTest.log(LogStatus.INFO, "5.Click on AngelFish");
		
		angelfish obj = new angelfish();
		
		obj.clickAddTocart(driver);
		
		System.out.println("6. Click on Add to cart button");
		
		extentTest.log(LogStatus.INFO, "6. Click on add to cart button");

		
		shoppingcart cart = new shoppingcart();
		
		cart.proceedToCheckout(driver);
		
		System.out.println("7. Click on Add to proceed to check out button");
		
		extentTest.log(LogStatus.INFO, "7. Click on Add to proceed to check out button");
		
		String actualResult = driver.findElement(By.xpath("//*[@id=\"Catalog\"]/form/p[1]")).getText();	
		
		
		String expectedResult = "Please enter your username and password.";
		
		if (expectedResult.equals(actualResult)) {
			 System.out.println("Test Pass");
				extentTest.log(LogStatus.PASS, "TEST PASS");

			
		}
		 else {
			 System.out.println("Test Fail");
				extentTest.log(LogStatus.FAIL, "TEST FAIL");


		}
		
		extent.endTest(extentTest);
		extent.flush();
		
		
	
	}

}
