package assignment;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import homepage.homepage;
import registernow.registernow;
import signin.signin;

public class assignment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriver driver = new ChromeDriver();
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\ayush\\eclipse-workspace\\testcases\\extention\\chromedriver.exe");
		
		System.out.println("1.open chrome");
		
		System.out.println("2.enter URL");
		
		driver.get("https://petstore.octoperf.com");
		
		driver.findElement(By.linkText("Enter the Store")).click();
		
		System.out.println("3. Click SignIn");
		
		homepage clickSignIn = new homepage();
		
		clickSignIn.clickSignIn(driver);
		
		System.out.println("4. Click Register Now!");
		
		signin clickRegisterNow = new signin();
		
		clickRegisterNow.register(driver);
		
		registernow fill = new registernow();
		
		System.out.println("5. Fill userID");

		
		fill.userID(driver);
		
		System.out.println("6. Fill password");

		fill.password(driver);
		
		System.out.println("7. Fill repeat password");
		
		fill.RepeatPassword(driver);
		
		fill.FirstName(driver);

		System.out.println("8. Fill lastname");
	
		fill.LastName(driver);

		System.out.println("9. Fill email");
		
		fill.Email(driver);
		
		System.out.println("10. Fill Phone");

		
		fill.Phone(driver);

		System.out.println("11. Fill Address");
		
		fill.Address(driver);
		
		System.out.println("12. Fill city");

		fill.City(driver);

		System.out.println("13. Fill State");

		fill.State(driver);
		
		System.out.println("12. Fill ZiP");
		
		fill.ZIP(driver);

		System.out.println("12. Fill Country");

		fill.Country(driver);
		
		System.out.println("13. Click checkboxes");
		
		registernow checkbox = new registernow();
		
		checkbox.LanguagePreference(driver);
		
		checkbox.Mybanner(driver);
		
		fill.save(driver);
		
		homepage home = new homepage();
		
		home.clickSignIn(driver);
		
		signin sign = new signin();
		
		sign.signIn(driver);

		
		//driver.close();
		
		
		

	}

}
