package shoppingcart;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class shoppingcart {
	
	public void proceedToCheckout(WebDriver dr)
	{
		dr.findElement(By.xpath("//*[@id=\"Cart\"]/a")).click();
	}
	
	public void removeItems(WebDriver dr)
	
	{
		System.out.println("Click removing items");
		dr.findElement(By.xpath("//*[@id=\"Cart\"]/form/table/tbody/tr[2]/td[8]/a")).click();
	}
	
	public void changeValue(WebDriver dr)
	
	{
		dr.findElement(By.name("EST-1")).click();
		dr.findElement(By.name("EST-1")).clear();
		dr.findElement(By.name("EST-1")).sendKeys("100");
		dr.findElement(By.name("updateCartQuantities")).click();
		
	}
	
public void changeValueToSymbol(WebDriver dr)
	
	{
		dr.findElement(By.name("EST-1")).click();
		dr.findElement(By.name("EST-1")).clear();
		dr.findElement(By.name("EST-1")).sendKeys("+");
		dr.findElement(By.name("updateCartQuantities")).click();
		
	}
	
public void changeValueToExceed(WebDriver dr)

{
	dr.findElement(By.name("EST-1")).click();
	dr.findElement(By.name("EST-1")).clear();
	dr.findElement(By.name("EST-1")).sendKeys("1000");
	dr.findElement(By.name("updateCartQuantities")).click();
	
}
public void changeValueToZero(WebDriver dr)

{
	dr.findElement(By.name("EST-1")).click();
	dr.findElement(By.name("EST-1")).clear();
	dr.findElement(By.name("EST-1")).sendKeys("0");
	dr.findElement(By.name("updateCartQuantities")).click();
	
}

public void changeValueToNegative(WebDriver dr)

{
	dr.findElement(By.name("EST-1")).click();
	dr.findElement(By.name("EST-1")).clear();
	dr.findElement(By.name("EST-1")).sendKeys("-23");
	dr.findElement(By.name("updateCartQuantities")).click();
	
}

public void clickDog(WebDriver dr)
{
	dr.findElement(By.xpath("//*[@id=\"QuickLinks\"]/a[2]/img")).click();
	
}
	
}
