package dog;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class dog {

	public void clickBulldog(WebDriver dr)
	{
		dr.findElement(By.linkText("K9-BD-01")).click();
	}
}
