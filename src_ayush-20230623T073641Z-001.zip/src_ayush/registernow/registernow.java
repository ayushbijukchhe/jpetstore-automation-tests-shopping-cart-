package registernow;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import io.opentelemetry.exporter.logging.SystemOutLogRecordExporter;

public class registernow {
	
	public void userID(WebDriver dr)
	{
		dr.findElement(By.name("username")).sendKeys("Ayush");
	}
	
	public void password(WebDriver dr)
	{
		dr.findElement(By.name("password")).sendKeys("Ayush1");
		
	}
	
	public void RepeatPassword(WebDriver dr)
	{
		dr.findElement(By.name("repeatedPassword")).sendKeys("Ayush1");

	}
	
	public void FirstName(WebDriver dr)
	{
		dr.findElement(By.name("account.firstName")).sendKeys("Ayush");

	}
	
	public void LastName(WebDriver dr)
	{
		dr.findElement(By.name("account.lastName")).sendKeys("Bijukchhe");

	}
	
	public void Email(WebDriver dr)
	{
		dr.findElement(By.name("account.email")).sendKeys("ayush.bijukchhe@gmail.com");

	}
	
	public void Phone(WebDriver dr)
	{
		dr.findElement(By.name("account.phone")).sendKeys("9861165900");

	}
	
	public void Address(WebDriver dr)
	{
		dr.findElement(By.name("account.address1")).sendKeys("Bhaktapur");

	}
	
	public void City(WebDriver dr)
	{
		dr.findElement(By.name("account.city")).sendKeys("Bhaktapur");

	}
	
	public void State(WebDriver dr)
	{
		dr.findElement(By.name("account.state")).sendKeys("Bagmati");

	}
	
	public void ZIP(WebDriver dr)
	{
		dr.findElement(By.name("account.zip")).sendKeys("46640");

	}
	
	
	
	public void Country(WebDriver dr)
	{		
		
		dr.findElement(By.name("account.country")).sendKeys("Nepal");

		
	}
	
	public void LanguagePreference(WebDriver dr)
	{
WebElement checkbox = dr.findElement(By.name("account.listOption"));
		
		checkbox.click();	
		
		if (checkbox.isSelected()) {
			
			System.out.println("checkbox selected");
			
		}
	}
	
	public void Mybanner(WebDriver dr)
	{
WebElement checkbox = dr.findElement(By.name("account.bannerOption"));
		
		checkbox.click();
		
		if (checkbox.isSelected()) {
			 
			System.out.println("check box is selected");
			
		}
	}
	
	public void save(WebDriver dr)
	
	{
		dr.findElement(By.name("newAccount")).click();
	}
	
	
	

}
