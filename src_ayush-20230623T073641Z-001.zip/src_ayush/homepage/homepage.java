package homepage;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.WebDriver;

public class homepage {

	public void clickFish(WebDriver dr)
	{
		dr.findElement(By.xpath("//*[@id=\"SidebarContent\"]/a[1]/img")).click();
	}
	
	public void clickShoppingCart(WebDriver dr)
	
	{
		dr.findElement(By.xpath("//*[@id=\"MenuContent\"]/a[1]/img")).click();
	}
	
	public void clickSignIn(WebDriver dr)
	
	{
		dr.findElement(By.xpath("//*[@id=\"MenuContent\"]/a[2]")).click();

	}
	
	public void clickCart(WebDriver dr)
	
	{
		dr.findElement(By.name("img_cart")).click();
	}
}
