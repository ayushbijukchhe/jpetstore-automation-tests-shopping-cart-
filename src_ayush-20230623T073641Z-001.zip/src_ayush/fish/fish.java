package fish;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class fish {
	
	public void clickFish(WebDriver dr)
	{
		dr.findElement(By.xpath("//*[@id=\"Catalog\"]/table/tbody/tr[2]/td[1]/a")).click();
		}

}
