package angelfish;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class angelfish {

	public void clickAddTocart(WebDriver dr)
	{
		dr.findElement(By.xpath("//*[@id=\"Catalog\"]/table/tbody/tr[2]/td[5]/a")).click();
	}
}
