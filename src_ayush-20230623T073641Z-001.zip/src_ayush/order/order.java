package order;
import org.openqa.selenium.WebDriver;
import angelfish.angelfish;
import bulldog.bulldog;
import dog.dog;
import fish.fish;
import homepage.homepage;
import shoppingcart.shoppingcart;

public class order {
	
	public void orderItem(WebDriver dr) {
	

	homepage home = new homepage();
	
	home.clickFish(dr);
	
	fish click = new fish();
	
	click.clickFish(dr);
	
	angelfish add = new angelfish();
	
	add.clickAddTocart(dr);
	
	shoppingcart clickdog = new shoppingcart();
	
	clickdog.clickDog(dr);
	
	dog click_bulldog = new dog();
	
	click_bulldog.clickBulldog(dr);
	
	bulldog click_Bulldog = new bulldog();
	
	click_Bulldog.addToCart(dr);
	
	
	}
}
